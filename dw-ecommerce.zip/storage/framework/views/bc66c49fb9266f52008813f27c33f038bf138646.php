<?php for($i=0; $i < count($prov['rajaongkir']['results']); $i++): ?>
	<option value="<?php echo e($prov['rajaongkir']['results'][$i]['province_id']); ?>"><?php echo e($prov['rajaongkir']['results'][$i]['province']); ?></option>
<?php endfor; ?>