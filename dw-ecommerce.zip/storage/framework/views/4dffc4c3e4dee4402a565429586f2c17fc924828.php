<?php $__env->startSection('title'); ?>
    <title>Toko Fashion Online Indonesia | <?php echo e($pengaturan->nama_toko); ?></title>
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="breadcrumbs">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i></a></li>
                    <li class="active">Home</li>
                </ol>
            </div>
        </div>
    </div>
    
    <div class="row" id="content">
        <div class="col-md-3">
            <?php echo $__env->make('includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="col-md-9">
            <div class="row carousel-holder">
                <div class="col-md-12">
                    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                        <ol class="carousel-indicators">
                            <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                            <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                            <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                        </ol>
                        <div class="carousel-inner">
                            <div class="item active">
                                <img class="slide-image" src="http://placehold.it/800x300" alt="">
                            </div>
                            <div class="item">
                                <img class="slide-image" src="http://placehold.it/800x300" alt="">
                            </div>
                            <div class="item">
                                <img class="slide-image" src="http://placehold.it/800x300" alt="">
                            </div>
                        </div>
                        <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                            <span class="glyphicon glyphicon-chevron-left"></span>
                        </a>
                        <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                            <span class="glyphicon glyphicon-chevron-right"></span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-primary">
                        <div class="panel-heading text-center">KOLEKSI TERBARU</div>
                            <div class="panel-body">
                                <?php foreach($product as $p): ?>
                                    <?php if($p->publish == 1): ?>
                                    <div class="col-md-3">
                                        <div class="thumbnail img-responsive">
                                            <?php if($p->media_image_id != null): ?>
                                                <a href="<?php echo e(url('/produk/' . $p->slug)); ?>"><img src="<?php echo e(asset('upload/img/' . $p->media_image->name_photo)); ?>" alt="<?php echo e($p->nama_produk); ?>" style="min-height:50px; height:250px; min-width:50px; width: 150px;" class="morph"></a>
                                            <?php else: ?>
                                                <a href="<?php echo e(url('/produk/' . $p->slug)); ?>"><img src="<?php echo e(asset('img/not-available.jpg')); ?>" alt="<?php echo e($p->nama_produk); ?>" style="min-height:50px; height:250px; min-width:50px; width: 150px;" class="morph"></a>
                                            <?php endif; ?>
                                            <hr>
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <p class="text-uppercase text-center">
                                                        <a href="<?php echo e(url('/produk/' . $p->slug)); ?>"><?php echo e(str_limit($p->nama_produk, 15)); ?></a>
                                                    </p>
                                                    <p class="text-center text-uppercase">(<?php echo e($p->kode_produk); ?>)</p>
                                                </div>
                                                <div class="col-md-12">
                                                    <p class="text-center harga">Rp. <?php echo e($p->harga_jual); ?> <?php if($p->diskon != 0): ?><sup><s><?php echo e($p->harga); ?></s></sup><?php endif; ?></p>
                                                </div>
                                                <div class="col-md-12 text-center">
                                                    <?php echo Form::open(array('url' => '/cart', 'class' => 'form_submit')); ?>

                                                        <a href=""><button class="btn btn-default btn-sm">Detail</button></a>
                                                        <button type="submit" class="btn btn-success btn-sm" id="beli"><i class="fa fa-shopping-cart"></i> Beli</button>
                                                        <input type="hidden" name="kode_produk" id="kode_produk" value="<?php echo e($p->kode_produk); ?>">
                                                    <?php echo Form::close(); ?>

                                                </div>
                                            </div>
                                            
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                            <div class="text-center"> 
                                <?php echo e($product->links()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <!-- Modal -->
            <div class="modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true" style="padding-top:15%; overflow-y:visible;" id="pesanmodal">
                <div class="modal-dialog">
                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><i class="fa fa-info-circle fa-2x"></i></h4>
                    </div>
                    <div class="modal-body">
                        <p><strong class="pmodal"></strong> Berhasil Ditambahkan Ke Keranjang.</p>
                    </div>
                    <div class="modal-footer">
                        <div class="row">
                            <div class="col-md-6">
                                <button type="button" class="btn btn-primary pull-left" data-dismiss="modal"><i class="fa fa-hand-o-left"></i> Lanjutkan Belanja</button>
                            </div>
                            <div class="col-md-6">
                                <a href="<?php echo e(url('/cart')); ?>"><button type="button" class="btn btn-primary pull-right"><i class="fa fa-shopping-cart"></i> Keranjang</button></a>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $(".form_submit").submit(function(event) {
            event.preventDefault();

            var formData = $(this).serialize(); 
            var formAction = $(this).attr("action"); 
            var formMethod = $(this).attr("method");

            $.ajaxSetup({
                headers: {
                    "X-XSRF-Token": $("meta[name='csrf_token']").attr("content")
                }
            });

            $.ajax({
                type  : formMethod,
                url   : formAction,
                data  : formData,

                success: function(data) {
                
                    waitingDialog.show('Menambahkan Ke keranjang, Silahkan Tunggu...');
                    setTimeout(function(){
                        waitingDialog.hide();
                        $("#pesanmodal").modal();
                    }, 1500);
                
                },
                error : function() {

                }
            });
            return false; 
        });
    });
</script>

<script type="text/javascript">
    var waitingDialog = waitingDialog || (function ($) {
    'use strict';

    var $dialog = $(
        '<div class="modal fade" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true" style="padding-top:15%; overflow-y:visible;">' +
        '<div class="modal-dialog modal-m">' +
        '<div class="modal-content">' +
            '<div class="modal-header"><h3 style="margin:0;"></h3></div>' +
            '<div class="modal-body">' +
                '<div class="progress progress-striped active" style="margin-bottom:0;"><div class="progress-bar" style="width: 100%"></div></div>' +
            '</div>' +
        '</div></div></div>');

    return {
        show: function (message, options) {
            if (typeof options === 'undefined') {
                options = {};
            }
            if (typeof message === 'undefined') {
                message = 'Loading';
            }
            var settings = $.extend({
                dialogSize: 'm',
                progressType: '',
                onHide: null
            }, options);

            $dialog.find('.modal-dialog').attr('class', 'modal-dialog').addClass('modal-' + settings.dialogSize);
            $dialog.find('.progress-bar').attr('class', 'progress-bar');
            if (settings.progressType) {
                $dialog.find('.progress-bar').addClass('progress-bar-' + settings.progressType);
            }
            $dialog.find('h3').text(message);
            if (typeof settings.onHide === 'function') {
                $dialog.off('hidden.bs.modal').on('hidden.bs.modal', function (e) {
                    settings.onHide.call($dialog);
                });
            }
            $dialog.modal();
        },
        hide: function () {
            $dialog.modal('hide');
        }
    };

})(jQuery);
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>