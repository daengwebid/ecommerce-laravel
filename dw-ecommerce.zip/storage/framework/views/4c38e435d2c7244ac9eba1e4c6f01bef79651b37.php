<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
	<p>Terima kasih telah melakukan order <b><?php echo e($name); ?></b></p>
	<p>INVOICE ID : <b>#<?php echo e($invoice); ?></b></p>
	<p>=============================</p>
	<p>Belanja anda : Rp. <?php echo e($belanja); ?></p>
	<p>Biaya Kirim : Rp. ~ </p>
	<p>TOTAL : <?php echo e($belanja); ?></p>
	<p>=============================</p>
	<br>
	<p>ALAMAT PENGIRIMAN</p>
	<p>=============================</p>
	<p>Atas Nama : <?php echo e($name); ?></p>
	<p>Alamat : <?php echo e($alamat); ?></p>
	<p>No Telp : <?php echo e($no_telp); ?></p>

	<br>
	<p>DETAIL ORDER</p>
	<p>=============================</p>
	<?php for($i=0; $i<count($detailorder); $i++): ?>
	<ol>
		<li><?php echo e($detailorder[$i]['nama_produk']); ?> = <?php echo e($detailorder[$i]['qty']); ?> ( <?php echo e($detailorder[$i]['berat']); ?> gram) @ Rp. <?php echo e($detailorder[$i]['harga']); ?></li>
	</ol>
	<?php endfor; ?>
	<br>
	<p><b>Silahkan Tunggu Email Konfirmasi pesanan sebelum melakukan transfer</b></p>
	<br>
	<p>Best Regards</p>
	<p><strong><?php echo e($nama_toko); ?></strong></p>
	<p>No Telp: <?php echo e($sms); ?>/<?php echo e($bbm); ?></p>
</body>
</html>