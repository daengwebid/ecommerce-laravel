<?php $__env->startSection('title'); ?>
	<title>Product | <?php echo e($pengaturan->nama_toko); ?></title>
	<meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.10/css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.10/css/jquery.dataTables.min.css">
	<script src="//cdn.datatables.net/1.10.10/js/jquery.dataTables.min.js"></script>
	<script src="//cdn.datatables.net/1.10.10/js/dataTables.bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>Data Product<small></small></h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Product</a></li>
            <li class="active">Data Product</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">

        <div class="col-md-12">
            <div class="box">
                <div class="box-header">
            	    <div class="pull-right"> 
				    	<a href="<?php echo e(url('/dw-admin/product/create')); ?>"><button class="btn btn-primary btn-sm">Add New</button></a>
				    </div>

                </div><!-- /.box-header -->
                
               
                <div class="table-responsive">

					<table class="table table-striped table-bordered display" id="produk">
				    	<thead>
				    		<tr>
					    		<th>Kode</th>
					    		<th>Photo</th>
					    		<th>Title</th>
					    		<th>Category</th>
					    		<th>Stock</th>
					    		<th>Price</th>
					    		<th>Date Created</th>
					    		<th>Published</th>
					    		<th></th>
				    		</tr>
				    	</thead>
				    	<tbody>

				    	<?php foreach($product as $item): ?>
				    		<tr>
					    		<td><?php echo e($item->kode_produk); ?></td>
					    		<?php if($item->media_image_id != null): ?>
					    			<td><a href="<?php echo e(url('/dw-admin/product/' . $item->id . '/edit')); ?>"><img class="img-thumbnail img-responsive" src="<?php echo e(asset('upload/img/' . $item->media_image->name_photo . '')); ?>" width="70"></a></td>
					    		<?php else: ?>
					    			<td><a href="<?php echo e(url('/dw-admin/product/' . $item->id . '/edit')); ?>"><img class="img-thumbnail img-responsive" src="<?php echo e(asset('img/not-available.jpg')); ?>" width="70"></a></td>
					    		<?php endif; ?>
					    		<td><a href="<?php echo e(url('/dw-admin/product/' . $item->id . '/edit')); ?>"><strong><?php echo e($item->nama_produk); ?></strong></a></td>
					    		<td><?php echo e($item->category->nama_kategori); ?></td>
					    		<td><?php echo e($item->stok); ?></td>
					    		<td><?php echo e($item->harga); ?></td>
					    		<td><?php echo e($item->created_at); ?></td>
					    		<td>
					    			<?php if($item->publish == 1): ?>
					    			<span class="label label-success">Active</span>
					    			<?php else: ?>
					    			<span class="label label-warning">Draft</span>
					    			<?php endif; ?>
					    		</td>
					    		<td>
					    		<?php echo e(Form::open(array('url'=>'/dw-admin/product/' . $item->id, 'method'=>'DELETE'))); ?>

					    		<button class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
					    		<?php echo e(Form::close()); ?>

					    		</td>
					    		
					    		<!--
					    		<td>
					    			<?php echo e(Form::open(array('method'=>'DELETE', 'route'=>array('dw-admin.product.destroy', $item->id)))); ?>

					    			<?php echo e(Form::submit('Delete', array('class'=>'btn btn-danger btn-sm'))); ?>

					    			<?php echo e(Form::close()); ?>

					    		</td>-->
				    		</tr>
				    	<?php endforeach; ?>

				    	</tbody>
				    </table>
				</div>

            </div><!-- /.box -->
        </div><!-- /.col -->
    	</div><!-- /.row -->
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->


<script>
    $(function() {
      $("#produk").DataTable({
     		columnDefs: [ { 
     			"visible": false, "orderable": false
     		}]
  		});
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>