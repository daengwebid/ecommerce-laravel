<div class="panel panel-primary">
                <div class="panel-heading">KATEGORI</div>
                    <div class="panel-body">
                        <ul class="nav">
                            <?php foreach($kategori as $k): ?>
                                <li><a href="<?php echo e(url('/kategori/' . $k->slug)); ?>" class="text-capitalize"> <?php echo e($k->nama_kategori); ?> <span class="fa fa-arrow-circle-right pull-right"></span></a></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
            </div>

            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">PAYMENT METHOD</h3>
                </div>
                <div class="panel-body">
                    Panel content
                </div>
            </div>