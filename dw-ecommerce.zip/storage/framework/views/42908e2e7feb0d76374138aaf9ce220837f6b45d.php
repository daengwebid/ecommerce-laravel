<?php echo e(session('cobalagi')); ?>

<?php echo e(session('detail')); ?>

<?php echo e(session('dada')); ?>