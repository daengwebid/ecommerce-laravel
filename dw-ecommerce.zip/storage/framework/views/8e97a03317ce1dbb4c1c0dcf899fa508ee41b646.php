<?php $__env->startSection('title'); ?>
    <title>Testimoni | <?php echo e($pengaturan->nama_toko); ?></title>
    <meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="breadcrumbs">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i></a></li>
                    <li class="active">Testimoni</li>
                </ol>
            </div>
        </div>
    </div>
    
    <div class="row" id="content">
        <div class="col-md-3">
            <?php echo $__env->make('includes.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="col-md-9">
            
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">From Testimoni</div>
                            <div class="panel-body">
                                <?php echo Form::open(array('url' => '/testimoni', 'class' => 'form-horizontal')); ?>

                                
                                <?php if(session('status')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <h4><i class="glyphicon glyphicon-info-sign"></i> Pemberitahuan</h4>
                                    <p><?php echo e(session('status')); ?></p>
                                </div>
                                <?php elseif(count($errors) > 0): ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                    <h4><i class="icon fa fa-ban"></i> Notification</h4>
                                    <ul>
                                        <?php foreach($errors->all() as $error): ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                                <?php endif; ?>

                                <div class="form-group">
                                  <?php echo Form::label('nama', 'Nama *', ['class'=>'control-label col-sm-3']); ?>

                                  <div class="col-sm-9"> 
                                    <?php echo Form::text('nama', null, ['class'=>'form-control', 'id'=>'nama', 'maxlength' => '20', 'required'=>'required']); ?>

                                  </div>
                                </div>

                                <div class="form-group">
                                  <?php echo Form::label('email', 'Email *', ['class'=>'control-label col-sm-3']); ?>

                                  <div class="col-sm-9"> 
                                    <?php echo Form::text('email', null, ['class'=>'form-control', 'id'=>'email', 'required'=>'required']); ?>

                                  </div>
                                </div>

                                <div class="form-group">
                                  <?php echo Form::label('no_hp', 'No Hp *', ['class'=>'control-label col-sm-3']); ?>

                                  <div class="col-sm-9"> 
                                    <?php echo Form::text('no_hp', null, ['class'=>'form-control', 'id'=>'no_hp', 'maxlength' => '12', 'required'=>'required']); ?>

                                  </div>
                                </div>

                                <div class="form-group">
                                  <?php echo Form::label('pesan', 'Testimoni *', ['class'=>'control-label col-sm-3']); ?>

                                  <div class="col-sm-9"> 
                                    <?php echo Form::textarea('pesan', null, ['class'=>'form-control', 'id'=>'pesan', 'maxlength' => '160', 'required'=>'required']); ?>

                                  </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-3"></label>
                                    <div class="col-sm-9">
                                        <?php echo Form::submit('Kirim', ['class'=>'btn btn-primary', 'id'=>'simpan']); ?>

                                    </div>
                                </div>

                                <?php echo Form::close(); ?>

                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>