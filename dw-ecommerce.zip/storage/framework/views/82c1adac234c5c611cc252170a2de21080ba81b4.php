<?php $__env->startSection('title'); ?>
    <title>Transaksi Berhasil | <?php echo e($pengaturan->nama_toko); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="breadcrumbs">
                <ol class="breadcrumb">
                    <li><a href="<?php echo e(url('')); ?>"><i class="fa fa-home"></i></a></li>
                    <li class="active">Finish</li>
                </ol>
            </div>
        </div>
    </div>

    <div class="row" id="content">
        <div class="col-md-12">
            <?php if(session('invoice')): ?>
            <div class="panel panel-default">
                <div class="panel-heading">Terima Kasih, Pesanan Anda Telah Kami Terima</div>
                <div class="panel-body">
                    <p>Hai <strong><?php echo e(session('customer')); ?></strong></p>
                    <p>Terima kasih telah berbelanja di <strong><?php echo e($pengaturan->nama_toko); ?>.</strong></p>
                    <p>Bersama dengan ini kami juga telah mengirimkan detail pesanan anda ke email <b><i><?php echo e(session('email')); ?></i></b> (Silahkan cek inbox/spam box).</p>
                    <p class="text-center"><img src="<?php echo e(asset('/img/progres.png')); ?>" class="img-responsive"></p>
                    <p>Invoice anda : </p>
                    <input type="text" name="invoice" value="#<?php echo e(session('invoice')); ?>" disabled="" style="background: #000; color: #fff">
                    <p>Silahkan cek email kedua berisi <b>konfirmasi pesanan</b> dari kami sebelum melakukan transfer</p>
                </div>
            </div> 
            <?php else: ?>
            <div class="alert alert-danger" role="alert">
                <p>Belum ada barang yang ditambahkan ke keranjang belanja. </p>
            </div>
            
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>