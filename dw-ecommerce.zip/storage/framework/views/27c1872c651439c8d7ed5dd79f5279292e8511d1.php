<div class="panel panel-primary">
    <div class="panel-heading">KATEGORI</div>
        <div class="panel-body">
            <ul class="nav">
                <?php foreach($kategori as $k): ?>
                    <li><a href="<?php echo e(url('/kategori/' . $k->slug)); ?>" class="text-capitalize"> <?php echo e($k->nama_kategori); ?> <span class="fa fa-arrow-circle-right pull-right"></span></a></li>
                <?php endforeach; ?>
            </ul>
        </div>
</div>

<div class="panel panel-primary">
    <div class="panel-heading">
        <h3 class="panel-title">TESTIMONI</h3>
    </div>
    <div class="panel-body">
        <div id="testimoni" class="carousel slide">
            <!-- Indicators -->     
            <div class="carousel-inner">
                <?php foreach($testimoni as $testi): ?>           
                <div class="item <?php echo e($testi->id == 1 ? 'active':''); ?>">
                    <p style="text-align: justify;"><?php echo e($testi->pesan); ?></p>
                    <p class="text-center">::..::..::</p>
                    <small><b><?php echo e($testi->nama); ?></b>
                        <i>(<?php echo e(str_limit($testi->no_hp, 9)); ?>)</i>
                    </small>
                </div>
                <?php endforeach; ?>
                <hr>
                <div class="pull-right">
                    <a href="<?php echo e(url('/testimoni')); ?>"><b>Testimoni Lengkap</b></a>
                </div>               
            </div> 
            
        </div><!-- End Carousel -->
    </div>
</div>

<div class="panel panel-primary">
    <div class="panel-heading">
        <h3 class="panel-title">PEMBAYARAN</h3>
    </div>
    <div class="panel-body">
        <?php foreach($bank as $b): ?>
            <img src="<?php echo e(asset('/img/logo-bri.png')); ?>" class="img-responsive center-block" width="150px" height="150px">
            <p class="text-center"><?php echo e($b->no_rekening); ?></p>
            <p class="text-center"><strong><?php echo e($b->nama_pemilik); ?></strong></p>
        <?php endforeach; ?>
    </div>
</div>