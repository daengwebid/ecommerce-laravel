<?php $__env->startSection('title'); ?>
	<title>Detail Supplier | <?php echo e($pengaturan->nama_toko); ?></title>
	<meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<script src="<?php echo e(asset('dist/js/jquery-2.1.4.min.js')); ?>"></script>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>Data Supplier<small></small></h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Supplier</a></li>
            <li class="active">Detail Supplier</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">

      	<div class="col-md-4">

            <!-- Profile Image -->
            <div class="box box-primary">
                <div class="box-body box-profile">
                	<h4>Detail Supplier Selected</h4>
                	<hr>

                	<!-- Detail -->
		              <div class="box box-primary">
		                <div class="box-body box-profile">
		                  <img class="profile-user-img img-responsive img-circle" src="<?php echo e(asset('img/logo-folded.png')); ?>" alt="Logo Supplier">
		                  <h3 class="profile-username text-center"><?php echo e($detail->nama_supplier); ?></h3>
		                  <p class="text-muted text-center"><?php echo e($detail->kota_supplier); ?></p>

		                  <ul class="list-group list-group-unbordered">
		                    <li class="list-group-item">
		                      <b>Website</b> <a href="<?php echo e($detail->website); ?>" class="pull-right"><?php echo e($detail->website); ?></a>
		                    </li>
		                    <li class="list-group-item">
		                      <b>Contact</b> <a class="pull-right"><?php echo e($detail->contact); ?></a>
		                    </li>
		                    
		                  </ul>

		                  <a href="<?php echo e(url('/dw-admin/supplier')); ?>" class="btn btn-primary btn-block"><b>Back</b></a>
		                </div><!-- /.box-body -->
		              </div><!-- /.box -->
		            <!-- End Detail -->


                </div><!-- /.box-body -->
            </div><!-- /.box -->

            
        </div><!-- /.col -->

        <div class="col-md-8">
            <div class="box">
                <div class="box-header">
            	    <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                
                <div class="table-responsive">
					<table class="table table-condensed">
				    	<thead>
				    		<tr>
					    		<th>#</th>
					    		<th>Name Supplier</th>
					    		<th>City</th>
					    		<th>Contact</th>
					    		<th colspan="2">Action</th>
				    		</tr>
				    	</thead>
				    	<tbody>
				    	<?php if($supplier == "[]"): ?>
				    		<tr>
				    			<td></td>
				    			<td colspan="4" class="text-center">No Records Found</td>
				    		</tr>
				    	<?php else: ?>

				    	<?php foreach($supplier as $item): ?>
				    		<tr>
					    		<td></td>
					    		<td><?php echo e($item->nama_supplier); ?></td>
					    		<td><?php echo e($item->kota_supplier); ?></td>
					    		<td><?php echo e($item->contact); ?></td>
					    		<td><a href="<?php echo e(url('/dw-admin/supplier/'. $item->id)); ?>" title="Show Detail"><button class="btn btn-default btn-sm"><i class="glyphicon glyphicon-folder-open"></i></td>
					    		<td>
					    			<?php echo e(Form::open(array('method'=>'DELETE', 'route'=>array('dw-admin.supplier.destroy', $item->id)))); ?>

					    			<?php echo e(Form::submit('Delete', array('class'=>'btn btn-danger btn-sm'))); ?>

					    			<?php echo e(Form::close()); ?>

					    		</td>
				    		</tr>
				    	<?php endforeach; ?>

				    	<?php endif; ?>
				    	</tbody>
				    </table>
				    <div class="pull-right"> 
				    	<?php echo $supplier->links(); ?>

				    </div>
				</div>

            </div><!-- /.box -->
        </div><!-- /.col -->
    	</div><!-- /.row -->
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>