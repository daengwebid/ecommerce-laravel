<?php $__env->startSection('title'); ?>
	<title>Order | <?php echo e($pengaturan->nama_toko); ?></title>
	<meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.10/css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.10/css/jquery.dataTables.min.css">
	<script src="//cdn.datatables.net/1.10.10/js/jquery.dataTables.min.js"></script>
	<script src="//cdn.datatables.net/1.10.10/js/dataTables.bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>Data Order<small></small></h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Order</a></li>
            <li class="active">Data Order</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">

        <div class="col-md-12">
            <div class="box">
                <div class="box-header">
            	    
                </div><!-- /.box-header -->
                
               
                <div class="table-responsive">

					<table class="table table-striped table-bordered display" id="produk">
				    	<thead>
				    		<tr>
					    		<th>Invoice</th>
					    		<th>Customer</th>
					    		<th>Shipping City</th>
					    		<th>Date Time</th>
					    		<th>Status</th>
					    		<th></th>
				    		</tr>
				    	</thead>
				    	<tbody>

				    	<?php foreach($order as $item): ?>
				    		<tr>
					    		<td><a href="<?php echo e(url('/dw-admin/order/' . $item->invoice)); ?>"><button class="btn btn-default btn-sm"><b><?php echo e($item->invoice); ?></b></button></a></td>
					    		<td><?php echo e($item->customer->nama_lengkap); ?></td>
					    		<td><?php echo e($item->city); ?></td>
					    		<td><?php echo e($item->created_at); ?></td>
					    		<td>
					    			<?php if($item->paid_id == null): ?>
					    			<span class="label label-warning">Waiting</span>
					    			<?php else: ?>
					    			<span class="label label-success">Verified</span>
					    			<?php endif; ?>
					    		</td>
					    		<td>
					    		<?php echo e(Form::open(array('url'=>'/dw-admin/order/' . $item->id, 'method'=>'DELETE'))); ?>

					    		<button class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
					    		<?php echo e(Form::close()); ?>

					    		</td>
					    		
				    		</tr>
				    	<?php endforeach; ?>

				    	</tbody>
				    </table>
				</div>

            </div><!-- /.box -->
        </div><!-- /.col -->
    	</div><!-- /.row -->
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->


<script>
    $(function() {
      $("#produk").DataTable({
     		"order": [[3, "desc"]]
  		});
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>