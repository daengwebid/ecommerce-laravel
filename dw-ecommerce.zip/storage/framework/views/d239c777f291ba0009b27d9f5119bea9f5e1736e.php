<?php $__env->startSection('title'); ?>
	<title>Pages | <?php echo e($pengaturan->nama_toko); ?></title>
	<meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.10/css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.10/css/jquery.dataTables.min.css">
	<script src="//cdn.datatables.net/1.10.10/js/jquery.dataTables.min.js"></script>
	<script src="//cdn.datatables.net/1.10.10/js/dataTables.bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>Data Page<small></small></h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Pages</a></li>
            <li class="active">Data Page</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">

        <div class="col-md-12">
            <div class="box">
                <div class="box-header">
            	    <h3 class="box-title"></h3>
                </div><!-- /.box-header -->
                
                <div class="table-responsive">
                	<a href="<?php echo e(url('/dw-admin/pages/create')); ?>"><button class="btn btn-primary btn-sm pull-right">Add New</button></a>
					<table class="table table-striped table-bordered display" id="kategori">
				    	<thead>
				    		<tr>
					    		<th>Title</th>
					    		<th>Slug</th>
					    		<th>Content</th>
					    		<th>Action</th>
				    		</tr>
				    	</thead>
				    	<tbody>
				    	<?php foreach($page as $item): ?>
				    		<tr>
				    			<td><a href="<?php echo e(url('/dw-admin/pages/' . $item->id . '/edit')); ?>"><strong><?php echo e($item->judul); ?></strong></a></td>
				    			<td><?php echo e($item->slug); ?></td>
				    			<td><?php echo str_limit($item->content, 30); ?></td>
				    			<td>
				    				<?php echo Form::open(array('url' => '/dw-admin/pages/' . $item->id, 'method' => 'DELETE')); ?>

				    					<?php echo Form::submit('Delete', ['class' => 'btn btn-danger btn-sm']); ?>

				    					
				    				<?php echo Form::close(); ?>

				    			</td>
				    		</tr>
				    	<?php endforeach; ?>
				    	</tbody>
				    </table>
				   
				</div>

            </div><!-- /.box -->
        </div><!-- /.col -->
    	</div><!-- /.row -->
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->

<script>
    $(function() {
      $("#kategori").DataTable({
     		columnDefs: [ { 
     			"visible": false, "orderable": false
     		}]
  		});
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>