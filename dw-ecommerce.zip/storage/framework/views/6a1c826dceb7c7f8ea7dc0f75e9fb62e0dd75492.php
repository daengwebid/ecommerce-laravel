<?php $__env->startSection('content'); ?>
<div class="container" style="margin-top:70px">
  <div class="row">
    <div class="col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-4">
      <div class="panel panel-default">
      
        <div class="panel-body">
          <?php if(count($errors) > 0): ?>
              <div class="alert alert-danger">
                  <ul>
                      <?php foreach($errors->all() as $error): ?>
                          <p>Username/Password Incorrect</p>
                      <?php endforeach; ?>
                  </ul>
              </div>
          <?php endif; ?>

          <?php echo Form::open(array('url'=>'/dw-admin/login')); ?>

          <?php echo csrf_field(); ?>

            <fieldset>
              <div class="row">
                <div class="center-block"> <img class="profile-img" src="<?php echo e(asset('img/logo.png')); ?>" class="img-responsive" alt=""> </div>
                <hr>
              </div>
              <div class="row">
                <div class="col-sm-12 col-md-10  col-md-offset-1 ">
                  <div class="form-group">
                  <?php echo Form::label('email', 'Email'); ?>

                    <div class="input-group"> <span class="input-group-addon"> <i class="glyphicon glyphicon-user"></i> </span>
                      <?php echo Form::text('email', old('username'), ['class'=>'form-control', 'placeholder'=>'Email', 'autofocus']); ?>

                    </div>
                  </div>
                  <div class="form-group">
                   <?php echo Form::label('password', 'Password'); ?>

                    <div class="input-group"> <span class="input-group-addon"> <i class="glyphicon glyphicon-lock"></i> </span>
                      <?php echo Form::password('password', ['class'=>'form-control', 'placeholder'=>'Placeholder']); ?>

                    </div>
                  </div>
                 
                  <div class="form-group">
                   <label>
                        <input type="checkbox" name="remember"> Remember Me
                    </label>
                    <?php echo Form::submit('Log In',['class'=>'btn btn-success']); ?>

                    <a class="btn btn-default" href="<?php echo e(url('/password/reset')); ?>">Forgot Your Password?</a>
                  </div>
                 
                </div>
              </div>
             
            </fieldset>
          <?php echo Form::close(); ?>

      
        </div>
      </div>
  </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>