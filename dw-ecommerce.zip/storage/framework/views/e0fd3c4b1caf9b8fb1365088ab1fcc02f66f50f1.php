<?php $__env->startSection('title'); ?>
	<title>Order | <?php echo e($pengaturan->nama_toko); ?></title>
	<meta name="csrf_token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.10/css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.10/css/jquery.dataTables.min.css">
	<script src="//cdn.datatables.net/1.10.10/js/jquery.dataTables.min.js"></script>
	<script src="//cdn.datatables.net/1.10.10/js/dataTables.bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>Order Detail<small></small></h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Order</a></li>
            <li class="active">Detail Order</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
	        <div class="col-md-12">
	        	<div class="box">
	            <table class="table table-responsive table-bordered">
		            <thead>
		            	<tr>
		            		<td><h3><i class="glyphicon glyphicon-list-alt"></i> Invoice ID : #<?php echo e($order->invoice); ?></h3></td>
		            		<td>
		            			<h3>Status : 
		            				<?php if($order->status_order == 'Complete'): ?> 
		            					<span class="label label-success"><?php echo e($order->status_order); ?></span> 
		            				<?php elseif($order->status_order == 'Proses Pengiriman'): ?> 
		            					<span class="label label-primary"><?php echo e($order->status_order); ?></span>
		            				<?php elseif($order->status_order == 'Pending'): ?>
		            					<span class="label label-warning"><?php echo e($order->status_order); ?></span>
		            				<?php elseif($order->status_order == 'Batal'): ?>
		            					<span class="label label-default"><?php echo e($order->status_order); ?></span>
		            				<?php endif; ?>
		            			</h3>
		            		</td>
		            	</tr>
		            </thead>
		            <tbody>
		            	<tr>
		            		<td></td>
		            		<td><button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#status_order"><i class="fa fa-refresh"></i> Update Status Order</button></td>
		            	</tr>
		            	<tr>
		            		<td>Customer : <a href="<?php echo e(url('#')); ?>"><?php echo e($order->customer->email); ?></a></td>
		            		<td>Time Order : <?php echo e(date('d-m-Y-H:i:s', strtotime($order->created_at))); ?></td>
		            	</tr>
		            </tbody>
	            </table>
	            </div>
	        </div><!-- /.col -->

	        <div class="col-md-12">
	        	<div class="panel panel-default">
				  	<div class="panel-heading panel-heading-sm">
                     	<h5 class="panel-title"><i class="fa fa-refresh"></i> Detail Order</h5>
                	</div>
				</div>
	        </div>

	        <div class="col-md-6">
	        	<div class="panel panel-default">
	        		<div class="panel-heading">
	        			<h5 class="panel-title"><i class="fa fa-bookmark-o"></i> Alamat Pengiriman</h5>
	        		</div>
	        		<div class="panel-body">
	        			<table class="table table-responsive table-bordered">
	        				<thead>
	        					<tr>
	        						<td>Nama </td>
	        						<td>: <?php echo e($order->customer->nama_lengkap); ?></td>
	        					</tr>
	        				</thead>
	        				<tbody>
	        					<tr>
	        						<td>Alamat</td>
	        						<td>: <?php echo e($order->alamat); ?></td>
	        					</tr>
	        					<tr>
	        						<td>Provinsi</td>
	        						<td>: <?php echo e($order->province); ?></td>
	        					</tr>
	        					<tr>
	        						<td>Kota</td>
	        						<td>: <?php echo e($order->city); ?></td>
	        					</tr>
	        					<tr>
	        						<td>Kode Pos</td>
	        						<td>: <?php echo e($order->kode_pos); ?></td>
	        					</tr>
	        					<tr>
	        						<td>No HP</td>
	        						<td>: <?php echo e($order->customer->no_hp); ?></td>
	        					</tr>
	        				</tbody>
	        			</table>
	        		</div>
	        	</div>
	        </div>
	        <div class="col-md-6">
	        	<div class="panel panel-default">
	        		<div class="panel-heading">
	        			<h5 class="panel-title"><i class="fa fa-plane"></i> Jasa Pengiriman</h5>
	        		</div>
	        		<div class="panel-body">
	        			<table class="table table-responsive table-bordered">
	        				<thead>
	        					<tr>
	        						<td>Paket </td>
	        						<td>: JNE</td>
	        					</tr>
	        				</thead>
	        				<tbody>
	        					<tr>
	        						<td>Service</td>
	        						<td>: -</td>
	        					</tr>
	        					<tr>
	        						<td>Deskripsi</td>
	        						<td>: -</td>
	        					</tr>
	        					<tr>
	        						<td>Estimasi</td>
	        						<td>: -</td>
	        					</tr>
	        				</tbody>
	        			</table>
	        		</div>
	        	</div>
	        </div>

	        <div class="col-md-12">
	        	<div class="panel panel-default">
	        		<div class="panel-heading">
	        			<h5 class="panel-title"><i class="fa fa-cubes"></i> Order Items</h5>
	        		</div>
	        		<div class="panel-body">
	        			<table class="table table-responsive table-bordered">
	        				<thead>
	        					<tr>
	        						<th>Item </th>
	        						<th>Qty</th>
	        						<th>Harga</th>
	        					</tr>
	        				</thead>
	        				<tbody>
	        				<?php foreach($order->order_detail as $item): ?>
	        					<tr>
	        						<td>
	        							<p>Nama : <strong><?php echo e($item->nama_produk); ?></strong></p>
	        							<p>Kode : <?php echo e($item->kode_produk); ?></p>
	        						</td>
	        						<td><?php echo e($item->qty); ?></td>
	        						<td><?php echo e($item->harga); ?></td>
	        					</tr>
	        				<?php endforeach; ?>
	        				</tbody>
	        			</table>
	        		</div>
	        	</div>
	        </div>
    	</div><!-- /.row -->
    </section><!-- /.content -->
</div><!-- /.content-wrapper -->

<!-- Modal update status -->
<div id="status_order" class="modal fade" role="dialog">
	<div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
    	<div class="modal-header">
        	<button type="button" class="close" data-dismiss="modal">&times;</button>
        	<h4 class="modal-title">Ubah Status Order</h4>
      	</div>
      	<div class="modal-body">
        	<?php echo Form::open(array('url' => '/dw-admin/status-order', 'class' => 'form-horizontal')); ?>

        		<label>Status Order</label>
        		<select class="form-control" name="status_order" required="">
        			<option value="">Pilih</option>
        			<option value="Complete">Complete</option>
        			<option value="Proses Pengiriman">Proses Pengiriman</option>
        			<option value="Pending">Pending</option>
        			<option value="Batal">Batal</option>
        		</select>
        		<label>No Resi</label>
        		<?php echo Form::text('no_resi', null, ['class' => 'form-control', 'id' => 'no_resi', 'placeholder' => 'Masukkan No Resi']); ?>

        		<label>Catatan</label>
        		<?php echo Form::textarea('catatan_status', null, ['class' => 'form-control', 'placeholder' => 'Catatan Order', 'cols' => '50', 'rows' => '5']); ?>

        		<?php echo Form::hidden('invoice', $order->invoice, ['class' => 'form-control', 'readonly' => 'readonly']); ?>

        	
      	</div>
      	<div class="modal-footer">
      		<?php echo Form::submit('Update', ['class' => 'btn btn-sm btn-primary']); ?>

        	<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
      		<?php echo Form::close(); ?>

      	</div>
    </div>

  	</div>
</div>
<!-- end modal -->

<script>
    $(function() {
      $("#produk").DataTable({
     		"order": [[3, "desc"]]
  		});
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>